# Eid Mubarak Static Web Template
A simple web template (html + css + js ) script to congratulate someone. In this sample script is congratulate about Eid Mubarak in Bahasa (Indonesia).

# Animated Demo

![ketupat](https://user-images.githubusercontent.com/25836292/42048197-b9ce85a6-7b2c-11e8-90ef-052bbba2923f.gif)

# Website Demo

Website demo click here! **[DEMO](https://sonadztux.github.io/eid_mubarak_html_template/index.html)**
